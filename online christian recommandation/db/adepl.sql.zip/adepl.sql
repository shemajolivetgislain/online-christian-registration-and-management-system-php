-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2017 at 06:46 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `adepl`
--

-- --------------------------------------------------------

--
-- Table structure for table `recommandation`
--

CREATE TABLE IF NOT EXISTS `recommandation` (
  `rid` int(100) NOT NULL AUTO_INCREMENT,
  `parishname` varchar(200) NOT NULL,
  `names` varchar(200) NOT NULL,
  `reason` varchar(250) NOT NULL,
  `district` varchar(200) NOT NULL,
  `parish` varchar(200) NOT NULL,
  `umudugudu` varchar(200) NOT NULL,
  `givedate` date NOT NULL,
  `validate` date NOT NULL,
  `place` varchar(100) NOT NULL,
  `todate` date NOT NULL,
  `pastorname` varchar(100) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `recommandation`
--

INSERT INTO `recommandation` (`rid`, `parishname`, `names`, `reason`, `district`, `parish`, `umudugudu`, `givedate`, `validate`, `place`, `todate`, `pastorname`) VALUES
(4, 'gakenke', 'murwanshyaka felix', 'kubera impanvu zi ishuri', 'musanze', 'kinigi', 'kinzovu', '2017-09-19', '2018-09-30', 'ngoma', '2017-09-23', 'shumbusho elie'),
(5, 'Nyamirambo', 'Iyakaremye', 'akazi', 'Gicumbi', 'muhura', 'Bumbogo', '2017-09-14', '2020-09-14', 'Karongi', '2017-09-14', 'Nyumbayire sirasi');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `aid` int(100) NOT NULL AUTO_INCREMENT,
  `image` varchar(200) NOT NULL,
  `afname` varchar(100) NOT NULL,
  `alname` varchar(100) NOT NULL,
  `amothername` varchar(100) NOT NULL,
  `afathername` varchar(100) NOT NULL,
  `region` varchar(100) NOT NULL,
  `aage` date NOT NULL,
  `asex` varchar(30) NOT NULL,
  `dateofbaptise` date NOT NULL,
  `cell` varchar(100) NOT NULL,
  `asector` varchar(100) NOT NULL,
  `adistrict` varchar(200) NOT NULL,
  `province` varchar(100) NOT NULL,
  `parish` int(100) NOT NULL,
  `telephone` int(100) NOT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=82 ;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`aid`, `image`, `afname`, `alname`, `amothername`, `afathername`, `region`, `aage`, `asex`, `dateofbaptise`, `cell`, `asector`, `adistrict`, `province`, `parish`, `telephone`) VALUES
(77, 'p4.jpg', 'murwanashyaka', 'felix', 'mulisa', 'murwanashyaka', 'kayonza', '1999-09-12', 'MALE', '2017-09-12', 'karagambe', 'bigogwe', 'rubavu', 'western', 0, 0),
(21, 'caj.jpg', 'jolivet', 'gislain', 'uwimana', 'kazoza', 'kibungo', '1998-09-04', 'male', '2017-09-13', 'karenge', 'kibungo', 'ngoma', 'eastern', 0, 0),
(23, '5.png', 'mukiza', 'roger', 'mukamana', 'karenzi', 'gisenyi', '2017-09-11', 'vcxz', '0000-00-00', 'kimironko', 'fchbx', 'kigali', 'eastern', 0, 0),
(25, 'p3.jpg', 'umurerwa', 'blandine', 'mukakarisa', 'rwamukwaya', 'kibungo', '2017-09-07', 'female', '2017-09-09', 'ds', 'kibungo', 'kigali', 'eastern', 0, 0),
(48, 'p5.jpg', 'ndatinya', 'dideudone', 'uwera', 'bonifasi', 'gisenyi', '1997-09-11', 'male', '2017-09-11', 'kinzovu', 'gatsata', 'kigali', 'kigali city', 0, 0),
(74, '09f2f8a014a0fd6ccd77303019879fc1--ocean-waves-christian-quotes.jpg', 'gahongayire', 'christine', 'mukakarenzi', 'sebagisha', 'kirehe', '1997-09-12', 'FEMALE', '2016-05-09', 'kinzovu', 'bigogwe', 'rubavu', 'western', 0, 0),
(72, 'shadow3.jpg', 'karen', 'mutangamundu', 'fdsgsda', 'bonifasi', 'rulindo', '1999-09-11', 'FEMALE', '2016-09-11', 'kabeza', 'kibungo', 'ngoma', 'eastern', 0, 0),
(78, 'arton90.jpg', 'tuyizere', 'jean dieu', 'mukamusige', 'karenzi', 'kayonza', '1999-10-30', 'male', '2017-09-20', 'kisange', 'kinzovu', 'kigali', 'kigali city', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `uid` int(14) NOT NULL AUTO_INCREMENT,
  `ufname` varchar(100) NOT NULL,
  `ulname` varchar(100) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `usector` varchar(100) NOT NULL,
  `udistrict` varchar(1000) NOT NULL,
  `uprovince` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telephone` int(100) NOT NULL,
  `national` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` int(100) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `ufname`, `ulname`, `sex`, `usector`, `udistrict`, `uprovince`, `email`, `telephone`, `national`, `username`, `password`) VALUES
(1, 'felix', 'murwnashyaka', 'male', 'kabarondo', 'rubavu', 'eastern', 'babug@gmail.com', 0, 2147483647, 'adminkigali', 1234),
(2, 'olivier', 'habiyambere', 'male', 'kinzovu', 'rubavu', 'western', 'habiolivier@gmail.com', 0, 2147483647, 'adminrubavu', 4321),
(3, '', '', '', '', '', '', '', 0, 0, 'admin', 123),
(4, '', '', '', '', '', '', '', 0, 0, 'adminhuye', 1234),
(17, 'kibungo', 'shema jolivet', 'job', 'kigali', 'karembo', 'kinzovu', '2017-09-12', 2019, 0, '', 0),
(16, '', '', '', '', '', '', '', 0, 0, 'adminngoma', 12),
(18, 'kibungo', 'shema jolivet', 'job', 'kigali', 'karembo', 'kinzovu', '2017-09-12', 2019, 0, '', 0),
(14, '', '', '', '', '', '', '', 0, 0, 'adminmusanze', 12345),
(19, '', '', '', '', '', '', '', 0, 0, '', 0),
(20, 'jytf', 'jyt', 'jyt', 'ujyt', 'jyt', 'jyt', '2017-09-04', 2017, 0, 'jyt', 0),
(21, 'castro', 'eric', 'eastern', 'kabarore', 'gastsibo', 'eastern', '', 783359558, 2147483647, 'amahoro', 12345),
(22, '', '', '', '', '', '', '', 0, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `workers`
--

CREATE TABLE IF NOT EXISTS `workers` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `jobstatus` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `sector` varchar(100) NOT NULL,
  `umudugudu` varchar(100) NOT NULL,
  `telephoneno` int(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `workers`
--

INSERT INTO `workers` (`id`, `fname`, `lname`, `status`, `jobstatus`, `sex`, `district`, `sector`, `umudugudu`, `telephoneno`) VALUES
(14, 'dsf', 'dsgf', 'ds', 'ds', 'male', '', 'dsaf', 'fdsa', 9806754),
(15, 'dsf', 'dsgf', 'ds', 'ds', 'male', '', 'dsaf', 'fdsa', 9806754),
(16, 'jolivet', 'shema', 'married', 'mwarimu', 'male', 'gicumbi', 'kibungo', 'karenge', 727968828),
(17, 'jolivet', 'shema', 'married', 'mwarimu', 'male', 'gicumbi', 'kibungo', 'karenge', 727968828),
(18, 'jolivet', 'shema', 'married', 'mwarimu', 'male', 'gicumbi', 'kibungo', 'karenge', 727968828),
(19, 'jolivet', 'shema', 'married', 'mwarimu', 'male', 'gicumbi', 'kibungo', 'karenge', 727968828);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
